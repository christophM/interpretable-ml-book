The tests in this directory are too slow to be part of the standard
CRAN tests.  Also they do diffs on postscript files, and the format of
those sometimes changes between R releases.  I run these test before
submitting a new version of this package to CRAN.
