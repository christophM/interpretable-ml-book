# xgboost.R:

plotmo.prolog.xgb.Booster <- function(object, object.name, trace, ...) # xgboost model
{
    stop0("xgboost models do not support plotmo and plotres")
}
