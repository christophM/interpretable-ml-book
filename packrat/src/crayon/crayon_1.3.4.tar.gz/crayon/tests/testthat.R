
library(crayon)
library(testthat)
test_check("crayon")
