#' @keywords internal
#' @import rlang
#' @useDynLib purrr, .registration = TRUE
"_PACKAGE"
