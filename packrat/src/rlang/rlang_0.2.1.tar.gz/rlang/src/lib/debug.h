#ifndef RLANG_DEBUG_H
#define RLANG_DEBUG_H


#define r_printf Rprintf


#endif
