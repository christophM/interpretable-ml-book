extern SEXP
    coin_expectationSym,
    coin_covarianceSym,
    coin_sumweightsSym;
