library(testthat)
library(mmpf)

test_check("mmpf")
