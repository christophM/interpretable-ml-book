#### -- Packrat Autoloader (version 0.4.9-3) -- ####
source("packrat/init.R")
#### -- End Packrat Autoloader -- ####
