cpp_create_environment <- function(names, xform, parent = parent.frame()) {
  do_test_create_environment(names, xform, parent)
}
