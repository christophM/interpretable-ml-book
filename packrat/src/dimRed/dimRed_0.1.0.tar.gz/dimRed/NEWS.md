
# dimRed 0.0.3.9001

  * Fixed kPCA predict function and documentation typos (@topepo #2)

  * Added predict and inverse functions

  * Added a function to extract rotation matrices from PCA and FastICA


# dimRed 0.0.3

  * First version on CRAN
