library(testthat)
library(viridisLite)

test_check("viridisLite")
