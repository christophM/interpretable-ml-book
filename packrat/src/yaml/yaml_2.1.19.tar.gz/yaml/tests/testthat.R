library(testthat)
library(yaml)

test_check('yaml')
