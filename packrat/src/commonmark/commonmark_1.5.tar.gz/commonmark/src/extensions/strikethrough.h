#ifndef STRIKETHROUGH_H
#define STRIKETHROUGH_H

#include "core-extensions.h"

extern cmark_node_type CMARK_NODE_STRIKETHROUGH;
cmark_syntax_extension *create_strikethrough_extension(void);

#endif
