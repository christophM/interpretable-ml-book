"power.refresh" <-
function(...) {
  power.examp(n=slider(no=1), stdev=slider(no=2), diff=slider(no=3),
              alpha=slider(no=4) )
}

