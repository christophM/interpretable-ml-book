slider.env <- new.env()

