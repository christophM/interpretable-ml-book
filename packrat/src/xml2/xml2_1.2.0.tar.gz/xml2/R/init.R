.onLoad <- function(lib, pkg){
  init_libxml2()
}
