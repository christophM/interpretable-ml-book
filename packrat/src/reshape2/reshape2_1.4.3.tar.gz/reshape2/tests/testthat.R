library(testthat)
library(reshape2)

test_check("reshape2")
