plot(1)
par(mar = rep(0, 4))
plot(2)
