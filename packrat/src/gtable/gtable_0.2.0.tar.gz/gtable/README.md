# gtable

[![Travis-CI Build Status](https://travis-ci.org/hadley/gtable.svg?branch=master)](https://travis-ci.org/hadley/gtable)
[![CRAN_Status_Badge](http://www.r-pkg.org/badges/version/gtable)](http://cran.r-project.org/package=gtable)
[![Coverage Status](https://img.shields.io/codecov/c/github/hadley/gtable/master.svg)](https://codecov.io/github/hadley/gtable?branch=master)

gtable provides internal tools used to draw ggplot2 graphics.
