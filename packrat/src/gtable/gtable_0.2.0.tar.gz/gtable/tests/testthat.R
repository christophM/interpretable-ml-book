library(testthat)
library(gtable)

test_check("gtable")
